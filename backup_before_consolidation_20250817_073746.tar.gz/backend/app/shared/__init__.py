"""
Shared infrastructure components
Contains common utilities, exceptions, and infrastructure code used across domains.
"""