"""
Shared middleware components
"""