"""
Shared infrastructure components.
"""