"""
Shared exception classes for the ENABLEDRM platform.
"""