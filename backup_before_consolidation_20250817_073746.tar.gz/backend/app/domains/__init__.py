"""
Domain layer for ENABLEDRM Platform
This package contains all business domains following Domain-Driven Design principles.
"""