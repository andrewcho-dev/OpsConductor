"""
Audit Domain Services
"""