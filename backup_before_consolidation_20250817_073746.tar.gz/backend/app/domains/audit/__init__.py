"""
Audit Domain - Security and compliance logging
"""