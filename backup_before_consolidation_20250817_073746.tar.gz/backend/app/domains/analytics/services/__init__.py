"""
Analytics Domain Services
"""