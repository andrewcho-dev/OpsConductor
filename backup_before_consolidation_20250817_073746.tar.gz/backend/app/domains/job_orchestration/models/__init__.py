"""
Job Orchestration Domain Models
"""