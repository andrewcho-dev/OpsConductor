"""
User Management Queries
"""