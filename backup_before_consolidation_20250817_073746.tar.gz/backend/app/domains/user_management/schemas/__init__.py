"""
User Management Domain Schemas
"""