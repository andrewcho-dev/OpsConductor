"""
User Management Domain Services
"""