"""
User Management Domain Events
"""