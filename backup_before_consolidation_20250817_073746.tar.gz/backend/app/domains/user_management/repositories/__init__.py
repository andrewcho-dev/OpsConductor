"""
User Management Domain Repositories
"""