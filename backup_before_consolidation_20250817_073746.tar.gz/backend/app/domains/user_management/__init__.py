"""
User Management Domain
Handles all user-related business logic including authentication, authorization, and user lifecycle.
"""