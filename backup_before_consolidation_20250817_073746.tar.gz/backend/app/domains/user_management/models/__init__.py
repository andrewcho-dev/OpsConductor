"""
User Management Domain Models
"""