"""
Security Domain Services
"""