"""
Target Management Domain
Handles all target-related business logic including target lifecycle, communication methods, and health monitoring.
"""