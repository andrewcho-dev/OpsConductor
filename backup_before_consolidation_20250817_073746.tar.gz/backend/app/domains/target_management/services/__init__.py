"""
Target Management Domain Services
"""