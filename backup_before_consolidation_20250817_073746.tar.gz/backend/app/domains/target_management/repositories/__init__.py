"""
Target Management Domain Repositories
"""