"""
Target Management Domain Models
"""