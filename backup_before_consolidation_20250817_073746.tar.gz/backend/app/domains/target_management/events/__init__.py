"""
Target Management Domain Events
"""