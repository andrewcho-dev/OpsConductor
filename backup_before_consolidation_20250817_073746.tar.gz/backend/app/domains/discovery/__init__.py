"""
Discovery Domain
Handles all network discovery and device detection business logic.
"""