"""
Discovery Domain Services
"""