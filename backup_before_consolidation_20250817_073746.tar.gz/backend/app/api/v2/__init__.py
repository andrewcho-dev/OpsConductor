"""
API v2 Package
Consolidated and standardized API endpoints for ENABLEDRM Platform
"""