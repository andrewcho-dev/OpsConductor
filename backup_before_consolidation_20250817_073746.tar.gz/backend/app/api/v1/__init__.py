"""
API v1 Package

Legacy and compatibility API endpoints.
"""