"""
API layer for OpsConductor Platform
"""